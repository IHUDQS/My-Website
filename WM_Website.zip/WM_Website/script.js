// script.js

const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
];

let currentYear = new Date().getFullYear();
let currentMonth = new Date().getMonth();

const events = {
    '2024-10-04': 'Welcome Dinner',
    '2024-08-27': 'Society Lunch',
    '2024-10-25': 'Roundtable Networking',
};

function generateCalendar(year, month) {
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const firstDay = new Date(year, month, 1).getDay();
    const lastDate = new Date(year, month + 1, 0).getDate();

    let calendarHtml = '<table class="calendar">';
    calendarHtml += '<tr>';
    daysOfWeek.forEach(day => calendarHtml += `<th>${day}</th>`);
    calendarHtml += '</tr><tr>';

    // Fill the first row with empty cells if the month does not start on Sunday
    for (let i = 0; i < firstDay; i++) {
        calendarHtml += '<td></td>';
    }

    // Fill the calendar with dates
    for (let date = 1; date <= lastDate; date++) {
        if ((firstDay + date - 1) % 7 === 0 && date !== 1) {
            calendarHtml += '</tr><tr>';
        }
        const currentDate = `${year}-${String(month + 1).padStart(2, '0')}-${String(date).padStart(2, '0')}`;
        const event = events[currentDate] ? `<span class="event" data-event="${events[currentDate]}">${date}</span>` : `<span>${date}</span>`;
        calendarHtml += `<td>${event}</td>`;
    }

    // Fill remaining cells if the month does not end on Saturday
    const totalCells = (firstDay + lastDate) % 7;
    if (totalCells !== 0) {
        for (let i = totalCells; i < 7; i++) {
            calendarHtml += '<td></td>';
        }
    }

    calendarHtml += '</tr></table>';
    return calendarHtml;
}

function updateMonthName() {
    const monthNameElement = document.getElementById('monthName');
    monthNameElement.textContent = `${monthNames[currentMonth]} ${currentYear}`;
}

function displayCalendar() {
    const calendarHtml = generateCalendar(currentYear, currentMonth);
    document.getElementById('calendar-container').innerHTML = calendarHtml;
    updateMonthName();
}

function changeMonth(offset) {
    currentMonth += offset;
    if (currentMonth > 11) {
        currentMonth = 0;
        currentYear++;
    } else if (currentMonth < 0) {
        currentMonth = 11;
        currentYear--;
    }
    displayCalendar();
}

document.getElementById('prevMonth').addEventListener('click', () => changeMonth(-1));
document.getElementById('nextMonth').addEventListener('click', () => changeMonth(1));

// Initialize the calendar on page load
displayCalendar();



// Articles carousel
document.addEventListener('DOMContentLoaded', () => {
    const carousel = document.querySelector('.carousel');
    const prevButton = document.getElementById('prev');
    const nextButton = document.getElementById('next');
    let index = 0;

    function updateCarousel() {
        const cardWidth = document.querySelector('.card').offsetWidth;
        carousel.style.transform = `translateX(${-index * (cardWidth + 20)}px)`; // 20px is the margin
    }

    nextButton.addEventListener('click', () => {
        index = (index + 1) % document.querySelectorAll('.card').length;
        updateCarousel();
    });

    prevButton.addEventListener('click', () => {
        index = (index - 1 + document.querySelectorAll('.card').length) % document.querySelectorAll('.card').length;
        updateCarousel();
    });

    // Initialize carousel position
    updateCarousel();
});





// members carousel
const prevButton = document.querySelector('.prev');
const nextButton = document.querySelector('.next');
const container = document.querySelector('.committee-container');

prevButton.addEventListener('click', () => {
    container.scrollBy({ top: -400, behavior: 'smooth' }); // Adjust scroll amount as needed
});

nextButton.addEventListener('click', () => {
    container.scrollBy({ top: 400, behavior: 'smooth' }); // Adjust scroll amount as needed
});